//
//  API.swift
//  WeatherApp
//
//  Created by Rustem Orazbek on 22.02.2021.
//

import Foundation

struct API {
    static let key = ""
}

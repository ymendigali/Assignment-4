//
//  WeatherAppApp.swift
//  WeatherApp
//
//  Created by Rustem Orazbek on 22.02.2021.
//

import SwiftUI

@main
struct WeatherAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
